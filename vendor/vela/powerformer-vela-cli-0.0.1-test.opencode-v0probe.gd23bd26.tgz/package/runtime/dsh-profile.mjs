import { readFileSync, realpathSync } from "node:fs";
// Vela's protocol plugin for the pinned official DeepSeek Harness. The launcher
// owns providers, storage and isolation; this plugin owns one ACP-facing session.
import { createRequire } from "node:module";
import { join } from "node:path";
import { createInterface } from "node:readline";
import { pathToFileURL } from "node:url";

// Resolve profile imports from Vela's explicitly pinned dependency scope.
// A consuming OD workspace may also install its own older DSH runtime.
const require = createRequire(import.meta.url);
function versionOf(id) {
  const owner =
    id === "@earendil-works/pi-ai"
      ? createRequire(require.resolve("@deepseek-ai/dsh-llm-pi-ai"))
      : require;
  for (const dir of owner.resolve.paths(id) ?? []) {
    try {
      const pkg = JSON.parse(
        readFileSync(join(dir, id, "package.json"), "utf8"),
      );
      if (pkg.name === id) return pkg.version;
    } catch {
      /* Follow the package owner's module search paths, never settings. */
    }
  }
  throw new Error(`Cannot identify installed package ${id}`);
}
const runtimeVersion = "0.1.5-rc.1";
// These are runtime/wire and model-adapter determinants. CLI version alone is
// insufficient because upstream declares floating transitive dependencies.
const pins = {
  "@deepseek-ai/cordis": "4.0.2",
  "@deepseek-ai/cordis-plugin-loader": "1.0.3",
  "@deepseek-ai/dsh-agent": runtimeVersion,
  "@deepseek-ai/dsh-agent-loop": runtimeVersion,
  "@deepseek-ai/dsh-agent-default-model": runtimeVersion,
  "@deepseek-ai/dsh-llm": runtimeVersion,
  "@deepseek-ai/dsh-llm-pi-ai": runtimeVersion,
  "@deepseek-ai/dsh-session": runtimeVersion,
  "@deepseek-ai/dsh-session-persistence-jsonl": runtimeVersion,
  "@deepseek-ai/dsh-attachment": runtimeVersion,
  "@deepseek-ai/dsh-invariants": runtimeVersion,
  "@deepseek-ai/dsh-settings": runtimeVersion,
  "@earendil-works/pi-ai": "0.85.1",
};
for (const [id, expected] of Object.entries(pins)) {
  const actual = versionOf(id);
  if (actual !== expected)
    throw new Error(
      `${id} version mismatch: require ${expected}, found ${actual}`,
    );
}
const { installModelSelection } = await import(
  pathToFileURL(require.resolve("@deepseek-ai/dsh-agent")).href
);
const { createUserMessage } = await import(
  pathToFileURL(require.resolve("@deepseek-ai/dsh-llm")).href
);

export const name = "vela-dsh-runtime";
export const inject = ["agents", "llm", "sessions", "sessionPersistence"];
const write = (value) =>
  process.stdout.write(`${JSON.stringify({ v: 1, ...value })}\n`);
const errorMessage = (error) =>
  typeof error?.message === "string" ? error.message : String(error);

export function apply(ctx) {
  const exit = ctx.get("appExit");
  if (!exit)
    throw new Error("Vela DSH profile requires the official appExit service");
  let handle;
  let selection;
  let active;
  let modelCallId = 0;
  let shuttingDown = false;
  let commandChain = Promise.resolve();
  const state = () => ({
    sessionId: String(handle.agent.session.id),
    provider: selection.current.provider,
    model: selection.current.model,
    runtime: "dsh",
    runtimeVersion,
    profileVersion: "1",
  });
  const resolveModel = async (model) => {
    if (typeof model !== "string" || model.length === 0)
      throw new Error("An explicit AMR model is required");
    await ctx.llm.resolveModelInfo("amr", model);
    return { provider: "amr", model };
  };
  // Auxiliary and in-process child calls do not add an assistant/message to
  // the root log. Observe their usage at the official LLM seam as well.
  ctx.on("llm/stream", async function* (options, next) {
    const turn = active;
    if (
      !turn ||
      options.provider !== "amr" ||
      options.model !== selection.current.model
    ) {
      throw new Error(
        "DSH model request is outside the selected AMR route or active prompt",
      );
    }
    const callId = String(++modelCallId);
    const sourceSessionId = String(options.sessionId ?? "");
    const auxiliary =
      sourceSessionId !== String(handle.agent.session.id) ||
      options.purpose !== undefined;
    if (sourceSessionId) turn.sessions.add(sourceSessionId);
    let usage;
    try {
      for await (const chunk of next()) {
        if (chunk.type === "usage") usage = chunk.usage;
        yield chunk;
      }
    } finally {
      if (auxiliary)
        write({
          type: "model_call",
          requestId: turn.requestId,
          sessionId: String(handle.agent.session.id),
          sourceSessionId,
          callId,
          provider: options.provider,
          model: options.model,
          ...(usage ? { usage } : {}),
        });
    }
  });
  const cancelActive = () => {
    active?.controller.abort();
    handle?.agent.cancel({ kind: "user" });
    for (const id of active?.sessions ?? [])
      ctx.agents.get(id)?.cancel({ kind: "user" });
  };
  const shutdown = async () => {
    if (shuttingDown) return;
    shuttingDown = true;
    cancelActive();
    await active?.task;
    if (handle) {
      await ctx.sessions.flush(handle.agent.session);
      await handle.dispose();
    }
    exit(0);
  };

  async function execute(command, turn) {
    let lastReason;
    let sawAssistant = false;
    const session = handle.agent.session;
    const startSeq = session.seq + 1;
    const emit = (event) =>
      write({
        ...event,
        requestId: command.requestId,
        sessionId: String(session.id),
      });
    const disposeStream = ctx.on(
      "agent/assistant-stream",
      ({ agent, frame }) => {
        // Only root assistant deltas belong in this request's response stream.
        if (agent.session.id !== session.id || frame.type !== "chunk") return;
        const chunk = frame.chunk;
        if (chunk.type === "text-delta")
          emit({ type: "text", text: chunk.text });
        if (chunk.type === "reasoning-delta")
          emit({ type: "thinking", text: chunk.text });
      },
    );
    const dispose = ctx.on("session/event", (owner, event) => {
      if (owner.id !== session.id && !turn.sessions.has(String(owner.id)))
        return;
      if (owner.id === session.id && event.seq < startSeq) return;
      // Child prose belongs to its tool, not the root assistant's text stream.
      if (
        owner.id !== session.id &&
        event.type !== "tool/call" &&
        event.type !== "tool/result"
      )
        return;
      switch (event.type) {
        case "assistant/message": {
          sawAssistant = true;
          // This is DSH's requested route, not HTTP response model evidence.
          // The Vela wire gateway verifies the actual response independently.
          const requested = session.requestContext();
          emit({
            type: "assistant",
            seq: event.seq,
            provider: requested?.provider,
            model: requested?.model,
            ...(event.data.usage ? { usage: event.data.usage } : {}),
          });
          break;
        }
        case "tool/call":
          emit({
            type: "tool_call",
            callId: String(event.data.callId),
            name: event.data.name,
            arguments: event.data.arguments,
          });
          break;
        case "tool/result": {
          const result = event.data.message.content[0];
          emit({
            type: "tool_result",
            callId: String(result.toolCallId),
            result: result.content,
            isError: result.isError === true,
          });
          break;
        }
        case "turn/end":
          lastReason = event.data.reason;
          break;
      }
    });
    try {
      await handle.agent.followup(
        createUserMessage({
          content: [{ type: "text", text: command.prompt }],
          source: { kind: "user" },
        }),
      );
      await handle.agent.whenIdle();
      let known = 0;
      while (known !== turn.sessions.size) {
        known = turn.sessions.size;
        await Promise.all(
          [...turn.sessions].map((id) => ctx.agents.get(id)?.whenIdle()),
        );
      }
      await Promise.all(
        [...turn.sessions].map(async (id) => {
          const owned = ctx.agents.get(id)?.session;
          if (owned && owned !== session) await ctx.sessions.flush(owned);
        }),
      );
      await ctx.sessions.flush(session);
      if (turn.controller.signal.aborted) {
        emit({ type: "result", status: "cancelled", stopReason: "cancelled" });
      } else if (
        sawAssistant &&
        (lastReason?.kind === "completed" || lastReason?.kind === "max-tokens")
      ) {
        emit({
          type: "result",
          status: "completed",
          stopReason:
            lastReason.kind === "max-tokens" ? "max_tokens" : "end_turn",
        });
      } else {
        emit({
          type: "result",
          status: "failed",
          error:
            lastReason?.kind === "error"
              ? errorMessage(lastReason.error)
              : `DSH ended without a successful assistant turn (${lastReason?.kind ?? "missing turn/end"})`,
        });
      }
    } catch (error) {
      emit({
        type: "result",
        status: turn.controller.signal.aborted ? "cancelled" : "failed",
        stopReason: "cancelled",
        error: errorMessage(error),
      });
    } finally {
      disposeStream();
      dispose();
      if (active === turn) active = undefined;
    }
  }

  async function dispatch(command) {
    if (shuttingDown) throw new Error("DSH is shutting down");
    if (command.type === "shutdown") {
      write({ type: "response", id: command.id, success: true, data: {} });
      void shutdown();
      return;
    }
    if (command.type === "cancel") {
      if (active?.requestId === command.requestId) {
        cancelActive();
      }
      return {};
    }
    if (active) throw new Error("DSH session is busy");
    if (command.type === "open") {
      if (handle)
        throw new Error("Only one DSH session is allowed per Vela process");
      if (!/^dsh-[0-9a-f]{32}$/.test(command.sessionId))
        throw new Error("Invalid DSH session id");
      const cwd = realpathSync(command.cwd);
      if (cwd !== realpathSync(process.env.VELA_DSH_WORKSPACE))
        throw new Error("DSH workspace mismatch");
      selection = {
        current: await resolveModel(command.model),
        assembled: undefined,
      };
      const setup = (agentCtx) => {
        installModelSelection(agentCtx, selection);
      };
      if (command.resume) {
        const snapshot = await ctx.sessionPersistence.stat(command.sessionId);
        const header = snapshot?.header;
        if (!header || header.parentSession || realpathSync(header.cwd) !== cwd)
          throw new Error("DSH session is unavailable in this AMR workspace");
        handle = await ctx.agents.resume({
          resumeSessionId: command.sessionId,
          agentOptions: selection.current,
          setup,
        });
      } else {
        handle = await ctx.agents.create({
          sessionId: command.sessionId,
          meta: { cwd },
          agentOptions: selection.current,
          setup,
        });
      }
      await handle.agent.whenIdle();
      // DSH 0.1.5 uses per-session persistence handles. The live session's
      // flush checkpoint drains that handle and materializes even an empty
      // new session before its durable identity is returned to the host.
      await ctx.sessions.flush(handle.agent.session);
      return state();
    }
    if (!handle) throw new Error("Open a DSH session first");
    if (command.type === "set_model") {
      selection.current = await resolveModel(command.model);
      return state();
    }
    if (command.type === "prompt") {
      if (
        typeof command.prompt !== "string" ||
        !command.prompt.trim() ||
        typeof command.requestId !== "string" ||
        !command.requestId
      ) {
        throw new Error("DSH prompt and request id are required");
      }
      const turn = {
        requestId: command.requestId,
        controller: new AbortController(),
        sessions: new Set(),
        task: undefined,
      };
      active = turn;
      // Acceptance precedes execution events; a prompt result is emitted only
      // after the real agent is idle and its durable session has been flushed.
      write({ type: "response", id: command.id, success: true, data: {} });
      turn.task = execute(command, turn);
      return;
    }
    throw new Error(`Unsupported DSH profile command ${command.type}`);
  }

  void ctx
    .get("loader")
    ?.await()
    .then(() => {
      const input = createInterface({
        input: process.stdin,
        crlfDelay: Number.POSITIVE_INFINITY,
      });
      input.on("line", (line) => {
        commandChain = commandChain.then(async () => {
          let command;
          try {
            command = JSON.parse(line);
            if (
              !command ||
              typeof command.id !== "string" ||
              typeof command.type !== "string"
            )
              throw new Error("Invalid DSH profile envelope");
            const data = await dispatch(command);
            if (data !== undefined)
              write({ type: "response", id: command.id, success: true, data });
          } catch (error) {
            write({
              type: "response",
              id: command?.id ?? "",
              success: false,
              error: errorMessage(error),
            });
          }
        });
      });
      input.on("close", () => {
        void commandChain.then(shutdown);
      });
      write({
        type: "ready",
        runtime: "dsh",
        runtimeVersion,
        profileVersion: "1",
        dependencies: pins,
      });
    })
    .catch((error) => {
      process.stderr.write(`Vela DSH boot failed: ${errorMessage(error)}\n`);
      exit(1);
    });
}
